import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { EventRepository } from '../repositories/event.repository';
import { EventListDto, CreateEventDto, UpdateEventDto, QueryCalendarDto } from '../dtos/event.dto';
import { Event } from '../entities/event.entity';
import { UserRepository } from '@/users/repositories/user.repository';
import { ServiceRepository } from '@/services/repositories/service.repository';
import { DoctorRepository } from '@/doctors/repositories/doctor.repository';
import { DoctorServiceRepository } from '@/doctors/repositories/doctor-service.repository';
import { Role, EventType } from '@/users/enum/user.enum';
import { UserRequest } from '@/auth/dto/auth.dto';
import { ListResponsePaginationDto } from '@/common/common.dto';
import { AnnouncementService } from '@/announcements/services/announcement.service';
import { EventViewRepository } from '../repositories/event.view.repository';
import { EventView } from '../entities/event.view.entity';
import { AnnouncementRepository } from '@/announcements/repositories/announcement.repository';
import { sendSmsIProg } from '@/helpers/sms.helper';

@Injectable()
export class EventService {
	constructor(
		private readonly eventRepository: EventRepository,
		private readonly eventViewRepository: EventViewRepository,
		private readonly userRepository: UserRepository,
		private readonly serviceRepository: ServiceRepository,
		private readonly doctorRepository: DoctorRepository,
		private readonly doctorServiceRepository: DoctorServiceRepository,
		private readonly announcementService: AnnouncementService,
		private readonly announcementRepository: AnnouncementRepository,
	) { }

	async createEvent(userId: string, createEventDto: CreateEventDto): Promise<Event> {
		if (userId !== createEventDto.user_id) {
			throw new BadRequestException('Unauthorized to create event');
		}

		const user = await this.userRepository.findOne({
			where: {
				id: createEventDto.user_id,
			},
			select: ['id', 'role'],
		});

		if (!user) {
			throw new NotFoundException('User not found');
		}

		if (![EventType.EVENT, EventType.APPOINTMENT].includes(createEventDto.type)) {
			throw new BadRequestException('Invalid event type');
		}

		if (createEventDto.type === EventType.EVENT && user.role !== (Role.ADMIN as string)) {
			throw new BadRequestException('Unauthorized to create event');
		}

		const eventData: Partial<Event> = {
			user_id: createEventDto.user_id,
			event_date: new Date(createEventDto.event_date),
			entity_type: createEventDto.type,
		};

		if (createEventDto.type === EventType.APPOINTMENT) {
			const service = await this.serviceRepository.findOne({ where: { id: createEventDto.service_id } });
			if (!service) {
				throw new NotFoundException('Service not found');
			}

			const doctor = await this.doctorRepository.findOne({ where: { id: createEventDto.doctor_id } });
			if (!doctor) {
				throw new NotFoundException('Doctor not found');
			}

			const doctorService = await this.doctorServiceRepository.findOne({
				where: {
					doctor_id: createEventDto.doctor_id || '',
					service_id: createEventDto.service_id || '',
				},
				select: ['id'],
			});
			if (!doctorService) {
				throw new NotFoundException('Doctor service not found');
			}

			eventData.entity_id = doctorService.id;
		} else if (createEventDto.type === EventType.EVENT) {
			const announcement = await this.announcementService.createAnnouncement(userId, {
				name: createEventDto.name,
				description: createEventDto.description,
			});

			eventData.entity_id = announcement.id;
		}

		const event = this.eventRepository.create(eventData);
		const savedEvent = await this.eventRepository.save(event);

		if (!savedEvent) {
			throw new NotFoundException('Something went wrong');
		}

		const eventView = await this.eventViewRepository.findOne({
			where: { event_id: savedEvent.id }
		});

		if (eventView) {
			if ((savedEvent.entity_type as EventType) === EventType.EVENT) {
				await this.sendSmsToBhw(eventView, 'created');
			} else if ((savedEvent.entity_type as EventType) === EventType.APPOINTMENT) {
				await this.sendSmsToAdmin(eventView, 'created');
			}
		}
		return savedEvent;
	}

	async findAll(req: UserRequest, query: EventListDto): Promise<ListResponsePaginationDto<EventView>> {
		const user = await this.userRepository.findOne({
			where: { id: req.user.id },
			select: ['id', 'role'],
		});
		return await this.eventViewRepository.findEvents(user, query);
	}

	async findOne(id: string): Promise<EventView> {
		const event = await this.eventViewRepository.findOne({
			where: { event_id: id },
		});
		if (!event) {
			throw new NotFoundException('Event not found');
		}
		return event;
	}

	async findCalendar(userId: string, query: QueryCalendarDto): Promise<EventView[]> {
		if (!query.from || !query.to || !query.type) {
			throw new BadRequestException('Missing required fields');
		}

		const user = await this.userRepository.findOne({
			where: { id: userId },
			select: ['id', 'role'],
		});
		if (!user) {
			throw new NotFoundException('User not found');
		}

		if (![Role.ADMIN as string, Role.USER as string].includes(user.role)) {
			throw new BadRequestException('Role Not found');
		}

		return await this.eventViewRepository.findEventsCalendar(user, query);
	}

	async update(userId: string, id: string, updateEventDto: UpdateEventDto): Promise<Event> {
		const event = await this.eventRepository.findOne({ where: { id } });
		let updatedEvent: Event;
		if (!event) {
			throw new NotFoundException('Event not found');
		}

		if (event.user_id !== userId) {
			throw new BadRequestException('Unauthorized to update');
		}

		if (event.event_date < new Date()) {
			throw new BadRequestException('Event date is in the past');
		}

		if (updateEventDto.type === EventType.EVENT) {
			// event update
			const announcement = await this.announcementRepository.findOne({ where: { id: event.entity_id } });
			if (!announcement) {
				throw new NotFoundException('Announcement not found');
			}

			const updatedAnnouncement = this.announcementRepository.create({
				...announcement,
				name: updateEventDto.name,
				description: updateEventDto.description,
			});

			await this.announcementRepository.save(updatedAnnouncement);

			updatedEvent = this.eventRepository.create({
				...event,
				event_date: new Date(updateEventDto.event_date),
				id,
			});

			const eventView = await this.eventViewRepository.findOne({
				where: { event_id: updatedEvent.id }
			});
			if (eventView) {
				await this.sendSmsToBhw(eventView, 'updated');
			}
		} else if (updateEventDto.type === EventType.APPOINTMENT) {
			// appointment update
			const service = await this.serviceRepository.findOne({ where: { id: updateEventDto.service_id }, select: ['id'] });
			if (!service) {
				throw new NotFoundException('Service not found');
			}

			const doctor = await this.doctorRepository.findOne({ where: { id: updateEventDto.doctor_id }, select: ['id'] });
			if (!doctor) {
				throw new NotFoundException('Doctor not found');
			}

			const doctorService = await this.doctorServiceRepository.findOne({
				where: {
					doctor_id: doctor.id,
					service_id: service.id,
				},
			});
			if (!doctorService) {
				throw new NotFoundException('Doctor service not found');
			}

			updatedEvent = this.eventRepository.create({
				...event,
				entity_id: doctorService.id,
				event_date: new Date(updateEventDto.event_date),
				id,
			});

			const eventView = await this.eventViewRepository.findOne({
				where: { event_id: updatedEvent.id }
			});
			if (eventView) {
				await this.sendSmsToAdmin(eventView, 'updated');
			}
		}

		return await this.eventRepository.save(updatedEvent);
	}

	async delete(userId: string, id: string): Promise<void> {
		const event = await this.eventRepository.findOne({ where: { id } });
		if (!event) {
			throw new NotFoundException('Event not found');
		}

		if (event.event_date < new Date()) {
			throw new BadRequestException('Event date is in the past');
		}

		const eventView = await this.eventViewRepository.findOne({
			where: { event_id: event.id }
		});

		if (eventView) {
			if ((event.entity_type as EventType) === EventType.APPOINTMENT) {
				if (userId !== event.user_id) {
					await this.sendSmsToAdmin(eventView, 'deleted');
				} else {
					await this.sendSmsToUser(eventView, userId, 'deleted');
				}
			} else if ((event.entity_type as EventType) === EventType.EVENT) {
				await this.sendSmsToBhw(eventView, 'deleted');
			}
		}

		await this.eventRepository.softDelete(id);
	}

	private getEventTypeText(eventType: string): string {
		return eventType === EventType.APPOINTMENT ? 'Appointment' : 'Event';
	}

	async sendSmsToBhw(eventView: EventView, action: 'created' | 'updated' | 'deleted' = 'updated') {
		const users = await this.userRepository.find({ where: { is_bhw: true } });
		const phoneNumber = users.map((user) => user.phone_number).filter(Boolean);
		const eventType = this.getEventTypeText(eventView.entity_type);

		let actionText = '';
		switch (action) {
			case 'created':
				actionText = 'New';
				break;
			case 'updated':
				actionText = 'Updated';
				break;
			case 'deleted':
				actionText = 'Cancelled';
				break;
		}

		let message = `[${eventType} ${actionText}]\n\n` +
			`Upcoming Community Event Notification\n\n` +
			`Event: ${eventView.announcement_name || 'New Event'}\n` +
			`Date: ${eventView.event_date ? new Date(eventView.event_date).toLocaleDateString('en-US', {
				year: 'numeric',
				month: 'long',
				day: 'numeric'
			}) : 'To be announced'}\n` +
			`Details: ${eventView.announcement_description || 'Join us for this special event.'}\n\n` +
			`Please mark your calendars and stay tuned for more details.`;

		console.log(`Sending SMS to BHW (${action}):`, message);

		// send sms to bhw
		await sendSmsIProg(phoneNumber.join(','), message, true);
	}

	async sendSmsToAdmin(eventView: EventView, action: 'created' | 'updated' | 'deleted' = 'updated') {
		const users = await this.userRepository.find({ where: { role: Role.ADMIN as string } });
		const phoneNumber = users.map((user) => user.phone_number).filter(Boolean);
		const eventType = this.getEventTypeText(eventView.entity_type);

		let actionText = '';
		switch (action) {
			case 'created':
				actionText = 'New';
				break;
			case 'updated':
				actionText = 'Updated';
				break;
			case 'deleted':
				actionText = 'Cancelled';
				break;
		}

		const message = `[${eventType} ${actionText}]\n\n` +
			`Date: ${eventView.event_date ? new Date(eventView.event_date).toLocaleDateString('en-US', {
				year: 'numeric',
				month: 'long',
				day: 'numeric'
			}) : 'N/A'}\n` +
			`Patient: ${eventView.user_firstname || 'N/A'} ${eventView.user_lastname || ''}\n` +
			`Service: ${eventView.service_name || 'N/A'}\n` +
			`Doctor: ${eventView.doctor_firstname || 'N/A'} ${eventView.doctor_lastname || ''}\n\n` +
			`Please check the system for more details.`;

		console.log(`Sending SMS to Admin (${action}):`, message);
		// send sms to admin
		await sendSmsIProg(phoneNumber.join(','), message, true);
	}

	async sendSmsToUser(eventView: EventView, userId: string, action: 'created' | 'updated' | 'deleted' = 'updated') {
		const user = await this.userRepository.findOne({ where: { id: userId } });
		if (!user || !user.phone_number) return;

		const phoneNumber = user.phone_number;
		const eventType = this.getEventTypeText(eventView.entity_type);

		let actionText = '';
		switch (action) {
			case 'created':
				actionText = 'scheduled';
				break;
			case 'updated':
				actionText = 'updated';
				break;
			case 'deleted':
				actionText = 'cancelled';
				break;
		}

		let message = '';
		if (action === 'deleted') {
			message = `Your ${eventType} has been ${actionText}.\n\n` +
				`Date: ${eventView.event_date ? new Date(eventView.event_date).toLocaleDateString('en-US', {
					year: 'numeric',
					month: 'long',
					day: 'numeric'
				}) : 'N/A'}\n` +
				`Service: ${eventView.service_name || 'N/A'}\n` +
				`Doctor: ${eventView.doctor_firstname || 'N/A'} ${eventView.doctor_lastname || ''}\n\n` +
				`If you have any questions, please contact us.`;
		} else {
			message = `Your ${eventType} has been ${actionText}.\n\n` +
				`Date: ${eventView.event_date ? new Date(eventView.event_date).toLocaleDateString('en-US', {
					year: 'numeric',
					month: 'long',
					day: 'numeric'
				}) : 'N/A'}\n` +
				`Service: ${eventView.service_name || 'N/A'}\n` +
				`Doctor: ${eventView.doctor_firstname || 'N/A'} ${eventView.doctor_lastname || ''}\n\n` +
				`Thank you for using our service.`;
		}

		console.log(`Sending SMS to User (${action}):`, message);

		console.log('Sending SMS to User:', message);
		// send sms to user
		await sendSmsIProg(phoneNumber, message);
	}
}
